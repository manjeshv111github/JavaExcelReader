package JavaExcel;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.CellReferenceType;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		File file = new File("C:\\Users\\ManjeshaV\\Desktop\\ExcelReader.xlsx");
		
		FileInputStream fo = new FileInputStream(file);
		
		XSSFWorkbook wb = new XSSFWorkbook(fo);
		
		XSSFSheet sheet = wb.getSheetAt(0);
		
		//Total row count
		
		int rowCount = sheet.getPhysicalNumberOfRows();
		 //OR
		//int rwcnt = sheet.getLastRowNum();
		
		
		//Total column count
		int colCount = sheet.getRow(0).getPhysicalNumberOfCells();
		
		System.out.println("Total Rows "+rowCount);
		System.out.println("Total Columns "+colCount);
		
		//String cellVal = sheet.getRow(0).getCell(0).getStringCellValue();
		//System.out.println(cellVal);
		
		for(int i=1;i<rowCount;i++) {
			for(int j=0;j<colCount;j++) {
				XSSFCell cellvalue = sheet.getRow(i).getCell(j); // not using getstringvalue() as we want it to accept all datatypes
				
				String val="";
				
				if(cellvalue.getCellType()==CellType.NUMERIC) {
					val=String.valueOf(cellvalue.getNumericCellValue());
							
				}
				else if (cellvalue.getCellType()==CellType.STRING) {
					
					val=cellvalue.getStringCellValue();
					
				}
				else if((cellvalue.getCellType()==CellType.BOOLEAN)) {
					val=String.valueOf(cellvalue.getBooleanCellValue());
				}
				
				System.out.println(val);
			
			}
		}	
		
	}

}
